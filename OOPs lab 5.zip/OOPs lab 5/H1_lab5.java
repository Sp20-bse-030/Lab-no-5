/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5;

/**
 *
 * @author Cyber World
 */
public class Distance {
    private int feets;
    private int inches;
    public Distance(){
        feets = 5;
        inches = 9;
    } 
    public Distance(int f, int i){
        feets = f;
        inches = i;
    }
    public void setFeets(int f){
        feets = f;
    }
    public int getFeets(){
        return feets;
    }
    public void setInches(int i){
        inches = i;
    }
    public int getInches(){
        return inches;
    }
    public Distance Add(Distance d1,Distance d2){
        Distance d = new Distance(feets+d1.feets+d2.feets, inches+d1.inches+d2.inches);
        return d;
    }
    public void Show(){
        System.out.println(feets);
        System.out.println(inches);
    }
            
}
