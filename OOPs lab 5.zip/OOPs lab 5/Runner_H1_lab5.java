/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg5;

/**
 *
 * @author Cyber World
 */
public class Runner_H1_lab5 {
    public static void main(String[]args){
        Distance D = new Distance();
        Distance D1 = new Distance(3,9);
        Distance D2 = new Distance(4,6);
        Distance D3 = new Distance(8,5);
        Distance D4 = D1.Add(D2, D3);
        D4.Show();
        
    }
    
}

