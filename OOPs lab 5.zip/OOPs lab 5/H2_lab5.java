/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg5;

/**
 *
 * @author Cyber World
 */
public class Book {
    private String author;
    private String book;
    private String [] chaptername = new String[100];
    public Book(){
        author = "Farhan";
        book = "Encyclopedia";
        
        
                
    }
    public Book(String s,String b){
        author = s;
        book = b;
    }

    
    public void setauthor(String s){
        author = s;
    }
    public String getauthor(){
        return author;
    }
     public void setbook(String b){
        book = b;
    }
    public String getbook(){
        return book;
    }
    public Book compareauthor(Book a){
        if(author == a.author){
            System.out.println("both author are same");
        return a;
        }
        else
            System.out.println("both authors are not same");
            return a;
    }
    
}
