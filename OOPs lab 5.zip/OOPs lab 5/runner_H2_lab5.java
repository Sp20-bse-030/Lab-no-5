/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg5;

/**
 *
 * @author Cyber World
 */
public class runner_H2_lab5 {
    public static void main(String[]args){
    Book b = new Book();
    Book b1 = new Book("Haider","Encyclopidea");
    Book b2 = new Book("Haider","physics");
    Book b3 = b1.compareauthor(b);
    Book b4 = b1.compareauthor(b2);
    
    
    }
   
}
