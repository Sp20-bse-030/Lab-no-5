/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg5;

/**
 *
 * @author Cyber World
 */
public class Runner_A1_lab5 {
    public static void main(String[]args){
         Friction f1 = new Friction(1 , 6);
        Friction f2 = new Friction();
        Friction f3 = new Friction(5,32);
        Friction f4 = new Friction(6,48);
        
        f2.setNuminator(5);
        f2.setDinuminator(30);
        
        f1.displayFraction();
        f2.displayFraction();
        
        
        
        
       f1.Equal(f2);
       f3.displayFraction();
        f4.displayFraction();
        f3.Equal(f4);
        
       
    }
}
