/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg5;

//import java.util.Scanner;

/**
 *
 * @author Cyber World
 */
public class Friction {
    private int n;
    private int d;
    public Friction(){
        n = 5;
        d = 15;
    }
    public Friction(int a , int b){
        n = a;
        d = b;
    }
    
    public void setNuminator(int a){
        n = a;
    }
    public void setDinuminator(int b){
        d = b;
    }
    public int getNuminator(){
        return n;
    }
    public int getDinuminator(){
        return d;
    }
    
    public void displayFraction(){
	System.out.print(n + "/" + d);
        System.out.println();
    }
    
    public boolean Equal(Friction f){
        int num = 1;
	for (int i = 2; i <= Math.min(n, d); i++){
              if (n % i == 0 && d % i == 0)
		    num = i;
	}

	n = n / num;
	d = d / num;
        
        for (int i = 2; i <= Math.min(f.n, f.d); i++){
              if (f.n % i == 0 && f.d % i == 0)
		    num = i;
	}
        
        f.n = f.n/num;
        f.d = f.d / num;
        
        if(n == f.n && d == f.d){
            System.out.println("both are identical");
            return true;
       }
        else{
            System.out.println("both are not identical");
            return false;
    
        }
        
        
    }
}
    
    

